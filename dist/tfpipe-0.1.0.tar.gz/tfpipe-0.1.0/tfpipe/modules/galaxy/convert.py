""" """
from tfpipe.base import CommandLine

class FastqToFasta(CommandLine):
    pass

