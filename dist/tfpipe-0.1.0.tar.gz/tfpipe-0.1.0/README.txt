======
tfpipe
======

tfpipe is short for Terry Furey Pipeline.  It is a simple framework for 
initializing and running workflows.  It generates pipeline workflows 
using the LSF scheduler on Kure.

Typical usage:

    #!/usr/bin/env python
    
    from tfpipe.modules.galaxy import FastqToFasta
    from tfpipe.pipeline import engine

    extend example....


More
====
*stuff 
*goes 
*here

Even More
---------

1. more
2. stuff
3. here




